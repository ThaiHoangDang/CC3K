#include "stair.h"


Stair::Stair(int x, int y): Object {'\\', "Stair", "blue", 0, x, y} {}


Stair::~Stair() {}
