#include "smallGold.h"


SmallGold::SmallGold(int x, int y): Treasure {"Small Gold", 1, x, y} {}


SmallGold::~SmallGold() {}
