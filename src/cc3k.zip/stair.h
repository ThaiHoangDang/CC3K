#ifndef STAIR_H
#define STAIR_H

#include <string>
#include "object.h"

class Stair: public Object {

    public:
        Stair(int x, int y);
        ~Stair();
};

#endif
