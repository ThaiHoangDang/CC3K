#include "normalGold.h"


NormalGold::NormalGold(int x, int y): Treasure {"Normal Gold", 2, x, y} {}


NormalGold::~NormalGold() {}
